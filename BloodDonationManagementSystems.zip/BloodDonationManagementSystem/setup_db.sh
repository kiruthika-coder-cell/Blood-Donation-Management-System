#!/usr/bin/env bash
# Creates the database, tables and sample data. Usage: ./setup_db.sh [mysql-user]
cd "$(dirname "$0")"
mysql -u "${1:-root}" -p < sql/schema.sql && echo "Database ready."
