#!/usr/bin/env bash
# Compiles and runs the Blood Donation Management System (Linux / macOS)
# Downloads the MySQL JDBC driver automatically on first run.
set -e
cd "$(dirname "$0")"

JAR=lib/mysql-connector-j-8.4.0.jar
if ! ls lib/*.jar >/dev/null 2>&1; then
  echo "Downloading MySQL JDBC driver..."
  mkdir -p lib
  if command -v curl >/dev/null 2>&1; then
    curl -fL -o "$JAR" https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.4.0/mysql-connector-j-8.4.0.jar
  else
    wget -O "$JAR" https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.4.0/mysql-connector-j-8.4.0.jar
  fi
fi

mkdir -p out
javac -cp "lib/*" -d out $(find src -name "*.java")
java -cp "out:lib/*" com.bloodbank.Main
