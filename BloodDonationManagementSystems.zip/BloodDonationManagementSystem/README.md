# Blood Donation Management System

Console app in plain Java (JDBC) + MySQL. No frameworks.

## Structure
```
BloodDonationManagementSystem/
├── config/db.properties        DB url / user / password
├── sql/schema.sql              tables + sample data
├── lib/                        put mysql-connector-j-*.jar here
├── src/com/bloodbank/
│   ├── Main.java               console menu
│   ├── model/                  Donor, Recipient, Donation, BloodStock, BloodRequest
│   ├── dao/                    DAO interfaces
│   ├── dao/impl/               JDBC implementations
│   ├── service/                DonationService (eligibility rules)
│   └── util/                   DBConnection, InputHelper, DAOException
├── run.sh / run.bat            compile + run
└── setup_db.sh / setup_db.bat  create the database
```

## Requirements
Java 17+ (JDK, `javac` on PATH), MySQL 8+, internet access on the first run.

## Run
1. Edit `config/db.properties` with your MySQL user/password.
2. Make sure MySQL is running, then start the app: `./run.sh` (Windows: `run.bat`).

On the first run the script downloads the MySQL driver into `lib/` and the app creates the
database, tables and sample data automatically. (`setup_db.sh/.bat` are optional manual alternatives.)

## Features
- Donor and recipient CRUD, search donors by blood group / city
- Donation recording with eligibility check (age 18-65, 90 days gap), updates stock in one transaction
- Blood requests: create, fulfil (deducts stock transactionally), reject
- Blood stock overview
