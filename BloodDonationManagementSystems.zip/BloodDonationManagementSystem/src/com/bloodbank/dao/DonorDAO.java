package com.bloodbank.dao;

import com.bloodbank.model.Donor;
import java.util.List;
import java.util.Optional;

public interface DonorDAO {
    int add(Donor donor);
    boolean update(Donor donor);
    boolean delete(int id);
    Optional<Donor> findById(int id);
    List<Donor> findAll();
    List<Donor> findByBloodGroup(String bloodGroup);
    List<Donor> findByCity(String city);
}
