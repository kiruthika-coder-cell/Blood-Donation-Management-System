package com.bloodbank.dao.impl;

import com.bloodbank.dao.DonationDAO;
import com.bloodbank.model.Donation;
import com.bloodbank.util.DAOException;
import com.bloodbank.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DonationDAOImpl implements DonationDAO {

    @Override
    public int recordDonation(Donation d) {
        Connection c = null;
        try {
            c = DBConnection.getConnection();
            c.setAutoCommit(false);

            int newId;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO donations (donor_id, donation_date, units) VALUES (?,?,?)",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, d.donorId());
                ps.setDate(2, Date.valueOf(d.date()));
                ps.setInt(3, d.units());
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    newId = rs.next() ? rs.getInt(1) : -1;
                }
            }

            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE blood_inventory SET units = units + ? "
                  + "WHERE blood_group = (SELECT blood_group FROM donors WHERE donor_id = ?)")) {
                ps.setInt(1, d.units());
                ps.setInt(2, d.donorId());
                ps.executeUpdate();
            }

            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE donors SET last_donation_date = ? WHERE donor_id = ?")) {
                ps.setDate(1, Date.valueOf(d.date()));
                ps.setInt(2, d.donorId());
                ps.executeUpdate();
            }

            c.commit();
            return newId;
        } catch (SQLException e) {
            rollback(c);
            throw new DAOException("Could not record donation: " + e.getMessage(), e);
        } finally {
            close(c);
        }
    }

    @Override
    public List<Donation> findAll() {
        return query("SELECT donation_id, donor_id, donation_date, units FROM donations ORDER BY donation_date DESC", -1);
    }

    @Override
    public List<Donation> findByDonor(int donorId) {
        return query("SELECT donation_id, donor_id, donation_date, units FROM donations "
                   + "WHERE donor_id=? ORDER BY donation_date DESC", donorId);
    }

    private List<Donation> query(String sql, int donorId) {
        List<Donation> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (donorId >= 0) ps.setInt(1, donorId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Donation(rs.getInt(1), rs.getInt(2), rs.getDate(3).toLocalDate(), rs.getInt(4)));
                }
            }
        } catch (SQLException e) {
            throw new DAOException("Could not read donations: " + e.getMessage(), e);
        }
        return list;
    }

    static void rollback(Connection c) {
        try { if (c != null) c.rollback(); } catch (SQLException ignored) { }
    }

    static void close(Connection c) {
        try { if (c != null) c.close(); } catch (SQLException ignored) { }
    }
}
