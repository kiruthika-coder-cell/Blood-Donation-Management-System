package com.bloodbank.dao.impl;

import com.bloodbank.dao.DonorDAO;
import com.bloodbank.model.Donor;
import com.bloodbank.util.DAOException;
import com.bloodbank.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DonorDAOImpl implements DonorDAO {

    private static final String COLS =
            "donor_id, name, age, gender, blood_group, phone, city, last_donation_date";

    @Override
    public int add(Donor d) {
        String sql = "INSERT INTO donors (name, age, gender, blood_group, phone, city, last_donation_date) "
                   + "VALUES (?,?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, d.name());
            ps.setInt(2, d.age());
            ps.setString(3, d.gender());
            ps.setString(4, d.bloodGroup());
            ps.setString(5, d.phone());
            ps.setString(6, d.city());
            if (d.lastDonationDate() == null) ps.setNull(7, Types.DATE);
            else ps.setDate(7, Date.valueOf(d.lastDonationDate()));
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        } catch (SQLException e) {
            throw new DAOException("Could not add donor: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Donor d) {
        String sql = "UPDATE donors SET name=?, age=?, gender=?, blood_group=?, phone=?, city=? WHERE donor_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, d.name());
            ps.setInt(2, d.age());
            ps.setString(3, d.gender());
            ps.setString(4, d.bloodGroup());
            ps.setString(5, d.phone());
            ps.setString(6, d.city());
            ps.setInt(7, d.id());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Could not update donor: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM donors WHERE donor_id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Could not delete donor: " + e.getMessage(), e);
        }
    }

    @Override
    public Optional<Donor> findById(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT " + COLS + " FROM donors WHERE donor_id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new DAOException("Could not find donor: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Donor> findAll() {
        return query("SELECT " + COLS + " FROM donors ORDER BY donor_id", null);
    }

    @Override
    public List<Donor> findByBloodGroup(String bloodGroup) {
        return query("SELECT " + COLS + " FROM donors WHERE blood_group=? ORDER BY name", bloodGroup);
    }

    @Override
    public List<Donor> findByCity(String city) {
        return query("SELECT " + COLS + " FROM donors WHERE city LIKE ? ORDER BY name", "%" + city + "%");
    }

    private List<Donor> query(String sql, String param) {
        List<Donor> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (param != null) ps.setString(1, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            throw new DAOException("Could not read donors: " + e.getMessage(), e);
        }
        return list;
    }

    private Donor map(ResultSet rs) throws SQLException {
        Date last = rs.getDate("last_donation_date");
        return new Donor(rs.getInt("donor_id"), rs.getString("name"), rs.getInt("age"),
                rs.getString("gender"), rs.getString("blood_group"), rs.getString("phone"),
                rs.getString("city"), last == null ? null : last.toLocalDate());
    }
}
