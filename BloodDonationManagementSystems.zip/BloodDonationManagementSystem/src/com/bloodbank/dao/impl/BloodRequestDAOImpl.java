package com.bloodbank.dao.impl;

import com.bloodbank.dao.BloodRequestDAO;
import com.bloodbank.model.BloodRequest;
import com.bloodbank.util.DAOException;
import com.bloodbank.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BloodRequestDAOImpl implements BloodRequestDAO {

    private static final String COLS = "request_id, recipient_id, blood_group, units, request_date, status";

    @Override
    public int create(BloodRequest r) {
        String sql = "INSERT INTO blood_requests (recipient_id, blood_group, units, request_date, status) "
                   + "VALUES (?,?,?,?,'PENDING')";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, r.recipientId());
            ps.setString(2, r.bloodGroup());
            ps.setInt(3, r.units());
            ps.setDate(4, Date.valueOf(r.requestDate()));
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        } catch (SQLException e) {
            throw new DAOException("Could not create request: " + e.getMessage(), e);
        }
    }

    @Override
    public List<BloodRequest> findAll() {
        return query("SELECT " + COLS + " FROM blood_requests ORDER BY request_id DESC");
    }

    @Override
    public List<BloodRequest> findPending() {
        return query("SELECT " + COLS + " FROM blood_requests WHERE status='PENDING' ORDER BY request_date, request_id");
    }

    @Override
    public void fulfill(int requestId) {
        Connection c = null;
        try {
            c = DBConnection.getConnection();
            c.setAutoCommit(false);

            String group;
            int units;
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT blood_group, units, status FROM blood_requests WHERE request_id=? FOR UPDATE")) {
                ps.setInt(1, requestId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new DAOException("Request #" + requestId + " not found.");
                    if (!"PENDING".equals(rs.getString("status")))
                        throw new DAOException("Request #" + requestId + " is already " + rs.getString("status") + ".");
                    group = rs.getString("blood_group");
                    units = rs.getInt("units");
                }
            }

            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE blood_inventory SET units = units - ? WHERE blood_group = ? AND units >= ?")) {
                ps.setInt(1, units);
                ps.setString(2, group);
                ps.setInt(3, units);
                if (ps.executeUpdate() == 0)
                    throw new DAOException("Not enough " + group + " blood in stock for this request.");
            }

            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE blood_requests SET status='FULFILLED' WHERE request_id=?")) {
                ps.setInt(1, requestId);
                ps.executeUpdate();
            }

            c.commit();
        } catch (DAOException e) {
            DonationDAOImpl.rollback(c);
            throw e;
        } catch (SQLException e) {
            DonationDAOImpl.rollback(c);
            throw new DAOException("Could not fulfil request: " + e.getMessage(), e);
        } finally {
            DonationDAOImpl.close(c);
        }
    }

    @Override
    public boolean reject(int requestId) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "UPDATE blood_requests SET status='REJECTED' WHERE request_id=? AND status='PENDING'")) {
            ps.setInt(1, requestId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Could not reject request: " + e.getMessage(), e);
        }
    }

    private List<BloodRequest> query(String sql) {
        List<BloodRequest> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new BloodRequest(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4),
                        rs.getDate(5).toLocalDate(), rs.getString(6)));
            }
        } catch (SQLException e) {
            throw new DAOException("Could not read requests: " + e.getMessage(), e);
        }
        return list;
    }
}
