package com.bloodbank.dao.impl;

import com.bloodbank.dao.InventoryDAO;
import com.bloodbank.model.BloodStock;
import com.bloodbank.util.DAOException;
import com.bloodbank.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InventoryDAOImpl implements InventoryDAO {

    @Override
    public List<BloodStock> findAll() {
        List<BloodStock> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT blood_group, units FROM blood_inventory ORDER BY blood_group")) {
            while (rs.next()) list.add(new BloodStock(rs.getString(1), rs.getInt(2)));
        } catch (SQLException e) {
            throw new DAOException("Could not read inventory: " + e.getMessage(), e);
        }
        return list;
    }

    @Override
    public int getUnits(String bloodGroup) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT units FROM blood_inventory WHERE blood_group=?")) {
            ps.setString(1, bloodGroup);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw new DAOException("Could not read inventory: " + e.getMessage(), e);
        }
    }
}
