package com.bloodbank.dao.impl;

import com.bloodbank.dao.RecipientDAO;
import com.bloodbank.model.Recipient;
import com.bloodbank.util.DAOException;
import com.bloodbank.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RecipientDAOImpl implements RecipientDAO {

    private static final String COLS = "recipient_id, name, age, gender, blood_group, phone, hospital";

    @Override
    public int add(Recipient r) {
        String sql = "INSERT INTO recipients (name, age, gender, blood_group, phone, hospital) VALUES (?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, r.name());
            ps.setInt(2, r.age());
            ps.setString(3, r.gender());
            ps.setString(4, r.bloodGroup());
            ps.setString(5, r.phone());
            ps.setString(6, r.hospital());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        } catch (SQLException e) {
            throw new DAOException("Could not add recipient: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Recipient r) {
        String sql = "UPDATE recipients SET name=?, age=?, gender=?, blood_group=?, phone=?, hospital=? WHERE recipient_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, r.name());
            ps.setInt(2, r.age());
            ps.setString(3, r.gender());
            ps.setString(4, r.bloodGroup());
            ps.setString(5, r.phone());
            ps.setString(6, r.hospital());
            ps.setInt(7, r.id());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Could not update recipient: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM recipients WHERE recipient_id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Could not delete recipient: " + e.getMessage(), e);
        }
    }

    @Override
    public Optional<Recipient> findById(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT " + COLS + " FROM recipients WHERE recipient_id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new DAOException("Could not find recipient: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Recipient> findAll() {
        List<Recipient> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT " + COLS + " FROM recipients ORDER BY recipient_id")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            throw new DAOException("Could not read recipients: " + e.getMessage(), e);
        }
        return list;
    }

    private Recipient map(ResultSet rs) throws SQLException {
        return new Recipient(rs.getInt("recipient_id"), rs.getString("name"), rs.getInt("age"),
                rs.getString("gender"), rs.getString("blood_group"), rs.getString("phone"),
                rs.getString("hospital"));
    }
}
