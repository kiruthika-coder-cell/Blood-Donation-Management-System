package com.bloodbank.dao;

import com.bloodbank.model.Donation;
import java.util.List;

public interface DonationDAO {
    /** Saves the donation, adds units to inventory and updates donor's last donation date (one transaction). */
    int recordDonation(Donation donation);
    List<Donation> findAll();
    List<Donation> findByDonor(int donorId);
}
