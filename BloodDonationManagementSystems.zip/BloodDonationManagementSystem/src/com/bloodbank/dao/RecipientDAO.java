package com.bloodbank.dao;

import com.bloodbank.model.Recipient;
import java.util.List;
import java.util.Optional;

public interface RecipientDAO {
    int add(Recipient recipient);
    boolean update(Recipient recipient);
    boolean delete(int id);
    Optional<Recipient> findById(int id);
    List<Recipient> findAll();
}
