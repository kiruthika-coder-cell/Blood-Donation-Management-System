package com.bloodbank.dao;

import com.bloodbank.model.BloodRequest;
import java.util.List;

public interface BloodRequestDAO {
    int create(BloodRequest request);
    List<BloodRequest> findAll();
    List<BloodRequest> findPending();
    /** Deducts stock and marks the request FULFILLED (one transaction). Throws DAOException if not possible. */
    void fulfill(int requestId);
    boolean reject(int requestId);
}
