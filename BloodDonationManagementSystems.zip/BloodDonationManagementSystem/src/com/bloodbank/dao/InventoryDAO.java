package com.bloodbank.dao;

import com.bloodbank.model.BloodStock;
import java.util.List;

public interface InventoryDAO {
    List<BloodStock> findAll();
    int getUnits(String bloodGroup);
}
