package com.bloodbank.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** On first run, creates the tables and sample data from sql/schema.sql (database itself is created via the JDBC url). */
public final class DatabaseInitializer {
    private DatabaseInitializer() { }

    public static void init() {
        try (Connection c = DBConnection.getConnection()) {
            try (ResultSet rs = c.getMetaData().getTables(c.getCatalog(), null, "donors", null)) {
                if (rs.next()) return;   // already set up
            }
            System.out.println("First run detected - creating tables and sample data...");
            String script = Files.readString(Path.of("sql/schema.sql"));
            try (Statement st = c.createStatement()) {
                for (String raw : script.split(";")) {
                    StringBuilder sb = new StringBuilder();
                    for (String line : raw.split("\\R")) {
                        if (!line.trim().startsWith("--")) sb.append(line).append('\n');
                    }
                    String sql = sb.toString().trim();
                    String up = sql.toUpperCase();
                    if (sql.isEmpty() || up.startsWith("CREATE DATABASE") || up.startsWith("USE ")) continue;
                    st.execute(sql);
                }
            }
            System.out.println("Database ready.");
        } catch (SQLException | IOException e) {
            throw new DAOException("Database setup failed: " + e.getMessage(), e);
        }
    }
}
