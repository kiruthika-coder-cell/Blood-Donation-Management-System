package com.bloodbank.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/** Creates JDBC connections using settings from config/db.properties. */
public final class DBConnection {
    private static final Properties PROPS = new Properties();

    static {
        try (InputStream in = new FileInputStream("config/db.properties")) {
            PROPS.load(in);
        } catch (IOException e) {
            throw new ExceptionInInitializerError(
                    "Cannot read config/db.properties (run the app from the project root): " + e.getMessage());
        }
    }

    private DBConnection() { }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                PROPS.getProperty("db.url"),
                PROPS.getProperty("db.user"),
                PROPS.getProperty("db.password"));
    }
}
