package com.bloodbank.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

/** Console input helpers with validation. */
public final class InputHelper {
    public static final List<String> BLOOD_GROUPS = List.of("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-");
    private static final Scanner SC = new Scanner(System.in);

    private InputHelper() { }

    public static String readString(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = SC.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("  Value cannot be empty.");
        }
    }

    public static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                int v = Integer.parseInt(SC.nextLine().trim());
                if (v >= min && v <= max) return v;
            } catch (NumberFormatException ignored) { }
            System.out.printf("  Enter a number between %d and %d.%n", min, max);
        }
    }

    public static String readBloodGroup(String prompt) {
        while (true) {
            String g = readString(prompt).toUpperCase();
            if (BLOOD_GROUPS.contains(g)) return g;
            System.out.println("  Valid groups: " + BLOOD_GROUPS);
        }
    }

    public static String readPhone(String prompt) {
        while (true) {
            String p = readString(prompt);
            if (p.matches("\\d{10}")) return p;
            System.out.println("  Phone must be 10 digits.");
        }
    }

    public static String readGender(String prompt) {
        while (true) {
            String g = readString(prompt).toLowerCase();
            switch (g) {
                case "m", "male" -> { return "Male"; }
                case "f", "female" -> { return "Female"; }
                case "o", "other" -> { return "Other"; }
                default -> System.out.println("  Enter M / F / O.");
            }
        }
    }

    /** Reads a date in yyyy-MM-dd format; blank returns null when allowBlank is true. */
    public static LocalDate readDate(String prompt, boolean allowBlank) {
        while (true) {
            System.out.print(prompt);
            String s = SC.nextLine().trim();
            if (s.isEmpty() && allowBlank) return null;
            try {
                return LocalDate.parse(s);
            } catch (DateTimeParseException e) {
                System.out.println("  Use format yyyy-MM-dd.");
            }
        }
    }
}
