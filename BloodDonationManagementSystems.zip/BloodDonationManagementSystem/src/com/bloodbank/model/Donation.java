package com.bloodbank.model;

import java.time.LocalDate;

public record Donation(int id, int donorId, LocalDate date, int units) {
    @Override
    public String toString() {
        return String.format("%-4d donor#%-4d %-12s %d unit(s)", id, donorId, date, units);
    }
}
