package com.bloodbank.model;

public record Recipient(int id, String name, int age, String gender, String bloodGroup,
                        String phone, String hospital) {
    @Override
    public String toString() {
        return String.format("%-4d %-20s %-4d %-8s %-5s %-12s %s",
                id, name, age, gender, bloodGroup, phone, hospital);
    }
}
