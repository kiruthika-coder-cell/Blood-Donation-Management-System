package com.bloodbank.model;

import java.time.LocalDate;

public record BloodRequest(int id, int recipientId, String bloodGroup, int units,
                           LocalDate requestDate, String status) {
    @Override
    public String toString() {
        return String.format("%-4d recipient#%-4d %-5s %d unit(s)  %-12s %s",
                id, recipientId, bloodGroup, units, requestDate, status);
    }
}
