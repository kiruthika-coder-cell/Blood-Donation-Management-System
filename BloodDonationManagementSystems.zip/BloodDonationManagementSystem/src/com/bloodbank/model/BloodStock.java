package com.bloodbank.model;

public record BloodStock(String bloodGroup, int units) {
    @Override
    public String toString() {
        return String.format("%-5s %d unit(s)", bloodGroup, units);
    }
}
