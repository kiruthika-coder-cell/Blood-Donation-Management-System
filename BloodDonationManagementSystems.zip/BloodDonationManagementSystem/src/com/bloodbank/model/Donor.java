package com.bloodbank.model;

import java.time.LocalDate;

public record Donor(int id, String name, int age, String gender, String bloodGroup,
                    String phone, String city, LocalDate lastDonationDate) {
    @Override
    public String toString() {
        return String.format("%-4d %-20s %-4d %-8s %-5s %-12s %-12s %s",
                id, name, age, gender, bloodGroup, phone, city,
                lastDonationDate == null ? "-" : lastDonationDate);
    }
}
