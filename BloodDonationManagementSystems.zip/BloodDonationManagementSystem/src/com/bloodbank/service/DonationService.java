package com.bloodbank.service;

import com.bloodbank.dao.DonationDAO;
import com.bloodbank.dao.DonorDAO;
import com.bloodbank.model.Donation;
import com.bloodbank.model.Donor;
import com.bloodbank.util.DAOException;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Business rules for donations (eligibility checks) on top of the DAO layer. */
public class DonationService {
    public static final int MIN_AGE = 18;
    public static final int MAX_AGE = 65;
    public static final int MIN_GAP_DAYS = 90;

    private final DonorDAO donorDAO;
    private final DonationDAO donationDAO;

    public DonationService(DonorDAO donorDAO, DonationDAO donationDAO) {
        this.donorDAO = donorDAO;
        this.donationDAO = donationDAO;
    }

    /** Returns null if eligible, otherwise the reason the donor can't donate today. */
    public String checkEligibility(Donor donor) {
        if (donor.age() < MIN_AGE || donor.age() > MAX_AGE)
            return "Donor age must be between " + MIN_AGE + " and " + MAX_AGE + ".";
        if (donor.lastDonationDate() != null) {
            long days = ChronoUnit.DAYS.between(donor.lastDonationDate(), LocalDate.now());
            if (days < MIN_GAP_DAYS)
                return "Last donation was " + days + " days ago; wait at least " + MIN_GAP_DAYS + " days.";
        }
        return null;
    }

    public int donate(int donorId, int units) {
        Donor donor = donorDAO.findById(donorId)
                .orElseThrow(() -> new DAOException("Donor #" + donorId + " not found."));
        String reason = checkEligibility(donor);
        if (reason != null) throw new DAOException("Not eligible: " + reason);
        return donationDAO.recordDonation(new Donation(0, donorId, LocalDate.now(), units));
    }
}
