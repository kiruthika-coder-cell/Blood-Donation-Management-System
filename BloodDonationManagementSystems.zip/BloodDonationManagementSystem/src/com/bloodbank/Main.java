package com.bloodbank;

import com.bloodbank.dao.*;
import com.bloodbank.dao.impl.*;
import com.bloodbank.model.*;
import com.bloodbank.service.DonationService;
import com.bloodbank.util.DatabaseInitializer;
import com.bloodbank.util.InputHelper;

import java.time.LocalDate;
import java.util.List;

/** Console entry point for the Blood Donation Management System. */
public class Main {

    private static final DonorDAO donorDAO = new DonorDAOImpl();
    private static final RecipientDAO recipientDAO = new RecipientDAOImpl();
    private static final DonationDAO donationDAO = new DonationDAOImpl();
    private static final InventoryDAO inventoryDAO = new InventoryDAOImpl();
    private static final BloodRequestDAO requestDAO = new BloodRequestDAOImpl();
    private static final DonationService donationService = new DonationService(donorDAO, donationDAO);

    public static void main(String[] args) {
        System.out.println("=== BLOOD DONATION MANAGEMENT SYSTEM ===");
        try {
            DatabaseInitializer.init();
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
            System.out.println("Check that MySQL is running and the user/password in config/db.properties are correct.");
            return;
        }
        boolean running = true;
        while (running) {
            System.out.println("""

                    1. Donors
                    2. Recipients
                    3. Record a donation
                    4. Blood requests
                    5. Blood stock
                    0. Exit""");
            int choice = InputHelper.readInt("Choose: ", 0, 5);
            try {
                switch (choice) {
                    case 1 -> donorMenu();
                    case 2 -> recipientMenu();
                    case 3 -> recordDonation();
                    case 4 -> requestMenu();
                    case 5 -> printAll(inventoryDAO.findAll(), "Blood stock");
                    case 0 -> running = false;
                }
            } catch (RuntimeException e) {
                System.out.println("  Error: " + e.getMessage());
            }
        }
        System.out.println("Goodbye!");
    }

    // ---------------- Donors ----------------
    private static void donorMenu() {
        System.out.println("""

                -- Donors --
                1. Add   2. Update   3. Delete   4. List all
                5. Search by blood group   6. Search by city   7. Donation history   0. Back""");
        switch (InputHelper.readInt("Choose: ", 0, 7)) {
            case 1 -> {
                int id = donorDAO.add(new Donor(0,
                        InputHelper.readString("Name: "),
                        InputHelper.readInt("Age: ", 1, 120),
                        InputHelper.readGender("Gender (M/F/O): "),
                        InputHelper.readBloodGroup("Blood group: "),
                        InputHelper.readPhone("Phone (10 digits): "),
                        InputHelper.readString("City: "),
                        InputHelper.readDate("Last donation date yyyy-MM-dd (blank if never): ", true)));
                System.out.println("  Donor added with ID " + id);
            }
            case 2 -> {
                int id = InputHelper.readInt("Donor ID: ", 1, Integer.MAX_VALUE);
                Donor old = donorDAO.findById(id).orElse(null);
                if (old == null) { System.out.println("  Donor not found."); return; }
                boolean ok = donorDAO.update(new Donor(id,
                        InputHelper.readString("Name: "),
                        InputHelper.readInt("Age: ", 1, 120),
                        InputHelper.readGender("Gender (M/F/O): "),
                        InputHelper.readBloodGroup("Blood group: "),
                        InputHelper.readPhone("Phone (10 digits): "),
                        InputHelper.readString("City: "),
                        old.lastDonationDate()));
                System.out.println(ok ? "  Donor updated." : "  Nothing updated.");
            }
            case 3 -> {
                int id = InputHelper.readInt("Donor ID: ", 1, Integer.MAX_VALUE);
                System.out.println(donorDAO.delete(id) ? "  Donor deleted." : "  Donor not found.");
            }
            case 4 -> printAll(donorDAO.findAll(), "Donors");
            case 5 -> printAll(donorDAO.findByBloodGroup(InputHelper.readBloodGroup("Blood group: ")), "Donors");
            case 6 -> printAll(donorDAO.findByCity(InputHelper.readString("City: ")), "Donors");
            case 7 -> printAll(donationDAO.findByDonor(InputHelper.readInt("Donor ID: ", 1, Integer.MAX_VALUE)),
                    "Donation history");
            default -> { }
        }
    }

    // ---------------- Recipients ----------------
    private static void recipientMenu() {
        System.out.println("""

                -- Recipients --
                1. Add   2. Update   3. Delete   4. List all   0. Back""");
        switch (InputHelper.readInt("Choose: ", 0, 4)) {
            case 1 -> {
                int id = recipientDAO.add(new Recipient(0,
                        InputHelper.readString("Name: "),
                        InputHelper.readInt("Age: ", 0, 120),
                        InputHelper.readGender("Gender (M/F/O): "),
                        InputHelper.readBloodGroup("Blood group needed: "),
                        InputHelper.readPhone("Phone (10 digits): "),
                        InputHelper.readString("Hospital: ")));
                System.out.println("  Recipient added with ID " + id);
            }
            case 2 -> {
                int id = InputHelper.readInt("Recipient ID: ", 1, Integer.MAX_VALUE);
                if (recipientDAO.findById(id).isEmpty()) { System.out.println("  Recipient not found."); return; }
                boolean ok = recipientDAO.update(new Recipient(id,
                        InputHelper.readString("Name: "),
                        InputHelper.readInt("Age: ", 0, 120),
                        InputHelper.readGender("Gender (M/F/O): "),
                        InputHelper.readBloodGroup("Blood group: "),
                        InputHelper.readPhone("Phone (10 digits): "),
                        InputHelper.readString("Hospital: ")));
                System.out.println(ok ? "  Recipient updated." : "  Nothing updated.");
            }
            case 3 -> {
                int id = InputHelper.readInt("Recipient ID: ", 1, Integer.MAX_VALUE);
                System.out.println(recipientDAO.delete(id) ? "  Recipient deleted." : "  Recipient not found.");
            }
            case 4 -> printAll(recipientDAO.findAll(), "Recipients");
            default -> { }
        }
    }

    // ---------------- Donations ----------------
    private static void recordDonation() {
        int donorId = InputHelper.readInt("Donor ID: ", 1, Integer.MAX_VALUE);
        int units = InputHelper.readInt("Units donated (1-3): ", 1, 3);
        int id = donationService.donate(donorId, units);
        System.out.println("  Donation recorded with ID " + id + ". Stock updated.");
    }

    // ---------------- Requests ----------------
    private static void requestMenu() {
        System.out.println("""

                -- Blood requests --
                1. New request   2. List all   3. List pending
                4. Fulfil request   5. Reject request   0. Back""");
        switch (InputHelper.readInt("Choose: ", 0, 5)) {
            case 1 -> {
                int recipientId = InputHelper.readInt("Recipient ID: ", 1, Integer.MAX_VALUE);
                Recipient r = recipientDAO.findById(recipientId).orElse(null);
                if (r == null) { System.out.println("  Recipient not found."); return; }
                String group = InputHelper.readBloodGroup("Blood group (" + r.bloodGroup() + " registered): ");
                int units = InputHelper.readInt("Units needed: ", 1, 20);
                int id = requestDAO.create(new BloodRequest(0, recipientId, group, units, LocalDate.now(), "PENDING"));
                System.out.println("  Request created with ID " + id);
            }
            case 2 -> printAll(requestDAO.findAll(), "Blood requests");
            case 3 -> printAll(requestDAO.findPending(), "Pending requests");
            case 4 -> {
                requestDAO.fulfill(InputHelper.readInt("Request ID: ", 1, Integer.MAX_VALUE));
                System.out.println("  Request fulfilled and stock updated.");
            }
            case 5 -> {
                int id = InputHelper.readInt("Request ID: ", 1, Integer.MAX_VALUE);
                System.out.println(requestDAO.reject(id) ? "  Request rejected." : "  No pending request with that ID.");
            }
            default -> { }
        }
    }

    private static <T> void printAll(List<T> items, String title) {
        System.out.println("\n-- " + title + " --");
        if (items.isEmpty()) System.out.println("  (none)");
        else items.forEach(i -> System.out.println("  " + i));
    }
}
