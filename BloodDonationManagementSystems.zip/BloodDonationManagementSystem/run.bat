@echo off
REM Compiles and runs the Blood Donation Management System (Windows)
REM Downloads the MySQL JDBC driver automatically on first run.
cd /d "%~dp0"

if not exist lib mkdir lib
dir /b lib\*.jar >nul 2>&1
if errorlevel 1 (
  echo Downloading MySQL JDBC driver...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri 'https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.4.0/mysql-connector-j-8.4.0.jar' -OutFile 'lib\mysql-connector-j-8.4.0.jar'"
  if errorlevel 1 (
    echo Download failed. Check your internet connection, or download the jar manually from
    echo https://dev.mysql.com/downloads/connector/j/ and place it in the lib folder.
    if exist lib\mysql-connector-j-8.4.0.jar del lib\mysql-connector-j-8.4.0.jar
    exit /b 1
  )
)

if not exist out mkdir out
dir /s /b src\*.java > sources.txt
javac -cp "lib\*" -d out @sources.txt
if errorlevel 1 (
  echo Compilation failed. Make sure a JDK 17+ is installed ^(javac must work in this terminal^).
  exit /b 1
)
java -cp "out;lib\*" com.bloodbank.Main
