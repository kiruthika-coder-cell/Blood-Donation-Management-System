-- Blood Donation Management System : MySQL schema + sample data
CREATE DATABASE IF NOT EXISTS blood_donation_db;
USE blood_donation_db;

DROP TABLE IF EXISTS blood_requests;
DROP TABLE IF EXISTS donations;
DROP TABLE IF EXISTS recipients;
DROP TABLE IF EXISTS donors;
DROP TABLE IF EXISTS blood_inventory;

CREATE TABLE donors (
    donor_id            INT AUTO_INCREMENT PRIMARY KEY,
    name                VARCHAR(100) NOT NULL,
    age                 INT NOT NULL CHECK (age BETWEEN 1 AND 120),
    gender              VARCHAR(10)  NOT NULL,
    blood_group         VARCHAR(3)   NOT NULL,
    phone               VARCHAR(15)  NOT NULL UNIQUE,
    city                VARCHAR(60)  NOT NULL,
    last_donation_date  DATE NULL,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE recipients (
    recipient_id  INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    age           INT NOT NULL CHECK (age BETWEEN 0 AND 120),
    gender        VARCHAR(10)  NOT NULL,
    blood_group   VARCHAR(3)   NOT NULL,
    phone         VARCHAR(15)  NOT NULL,
    hospital      VARCHAR(100) NOT NULL
);

CREATE TABLE blood_inventory (
    blood_group  VARCHAR(3) PRIMARY KEY,
    units        INT NOT NULL DEFAULT 0 CHECK (units >= 0)
);

CREATE TABLE donations (
    donation_id    INT AUTO_INCREMENT PRIMARY KEY,
    donor_id       INT NOT NULL,
    donation_date  DATE NOT NULL,
    units          INT NOT NULL CHECK (units > 0),
    FOREIGN KEY (donor_id) REFERENCES donors(donor_id) ON DELETE CASCADE
);

CREATE TABLE blood_requests (
    request_id    INT AUTO_INCREMENT PRIMARY KEY,
    recipient_id  INT NOT NULL,
    blood_group   VARCHAR(3) NOT NULL,
    units         INT NOT NULL CHECK (units > 0),
    request_date  DATE NOT NULL,
    status        ENUM('PENDING','FULFILLED','REJECTED') NOT NULL DEFAULT 'PENDING',
    FOREIGN KEY (recipient_id) REFERENCES recipients(recipient_id) ON DELETE CASCADE
);

INSERT INTO blood_inventory (blood_group, units) VALUES
 ('A+',5),('A-',2),('B+',6),('B-',1),('AB+',3),('AB-',0),('O+',8),('O-',2);

INSERT INTO donors (name, age, gender, blood_group, phone, city, last_donation_date) VALUES
 ('Arun Kumar', 28, 'Male',   'O+', '9876500001', 'Salem',      NULL),
 ('Priya S',    24, 'Female', 'B+', '9876500002', 'Namakkal',   '2026-01-15'),
 ('Karthik R',  35, 'Male',   'A+', '9876500003', 'Erode',      NULL);

INSERT INTO recipients (name, age, gender, blood_group, phone, hospital) VALUES
 ('Meena D', 40, 'Female', 'O+', '9876500101', 'Government Hospital, Salem');
