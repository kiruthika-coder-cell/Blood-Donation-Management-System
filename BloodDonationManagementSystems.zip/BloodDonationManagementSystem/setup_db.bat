@echo off
REM Creates the database, tables and sample data. Usage: setup_db.bat [mysql-user]
cd /d "%~dp0"
set DBUSER=%1
if "%DBUSER%"=="" set DBUSER=root
mysql -u %DBUSER% -p < sql\schema.sql && echo Database ready.
